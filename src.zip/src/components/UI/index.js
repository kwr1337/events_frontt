import MyButton from "@/components/UI/MyButton.vue";
import Title from "@/components/UI/Title.vue";

export default [
    MyButton,
    Title
]